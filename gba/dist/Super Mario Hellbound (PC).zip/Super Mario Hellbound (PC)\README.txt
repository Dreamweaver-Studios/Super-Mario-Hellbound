SUPER MARIO HELLBOUND (PC)
by Dreamweaver Studios

To play: unzip the whole folder anywhere you can write to (not Program Files), then run
"Super Mario Hellbound.exe". Your progress and high scores are saved in the game folder.

KEYBOARD
  Arrow keys   move / aim (UP aims up, UP+LEFT/RIGHT diagonally), DOWN crouches
  X            jump (A)
  Z            shoot (B)
  Enter        START: menus, pause
  Backspace    SELECT
  Alt+Enter    full screen on/off

GAMEPADS
  Most controllers work straight away. To change any button, use Tools > Settings > Controllers
  (keyboard: Tools > Settings > Keyboard).

CREDITS
  Dreamweaver Studios
  Sprites: Goldenfrank0, ansimuz, Jesse Munguia, Anokolisa
  Music: Bert Cole, Heatley Bros, Pixel 8 Beats, The Grump Sounds

ABOUT THE EMULATOR
  The game is a Game Boy Advance game. It runs in mGBA (https://mgba.io), included in the mgba folder
  in portable mode, so it keeps its own settings and doesn't change any mGBA you have installed.
  mGBA is (c) Jeffrey Pfau and contributors, distributed under the Mozilla Public License 2.0
  (mgba\LICENSE.txt; the licences of the libraries it uses are in mgba\licenses).
  Its source code is available at https://github.com/mgba-emu/mgba.